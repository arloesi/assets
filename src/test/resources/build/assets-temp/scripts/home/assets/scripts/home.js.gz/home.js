(function() {
  var main;

  main = function(i) {
    return console.log(i);
  };

}).call(this);
