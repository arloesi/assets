(function() {
  var common;

  common = function(x) {
    return console.log("common: " + x);
  };

}).call(this);
