(function() {
  this.utility = function(x) {
    return console.log("utility: " + x);
  };

}).call(this);
